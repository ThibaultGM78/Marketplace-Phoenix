<?php
$date=$_POST["date"];
$nom=$_POST["nom"];
$prenom=$_POST["prenom"];
$email=$_POST["email"];
$naissance=$_POST["naissance"];
$fonction=$_POST["fonction"];
$sujet=$_POST["sujet"];
$contenu=$_POST["contenu"];
$genre=$_POST["genre"];

?>