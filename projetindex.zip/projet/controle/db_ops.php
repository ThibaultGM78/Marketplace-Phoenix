<?php

function random_num($length)// function to create a random sequence of numbers for user_id
{
    for ($i=0; $i < $length; $i++) { 
        $text .= rand(0,9);
    }

    return $text;
}

function add($filename, $object){
    $file = fopen($filename,"a+");
    $filesize = filesize($filename);
    
    if($file == false) {
        echo ("ERREUR: Ouverture impossible !");
        exit();
    }  


    //Check if the id already exists in this table 
    $id=0;
    $findId=[];
    do{
        $id=random_num(4);
        $findId = findWith($filename, $filesize, $id, 0);
    }while($findId[0]);
    $new = strval($id);
    for($i=0; $i<count($object);$i++){
        $new = $new.';'.$object[$i];
    }
    
    fwrite($file, $new);
    fwrite($file, "\n");
    fclose($file);
}

function read($filename, $id){
    $file = fopen($filename,"r");
    $filesize = filesize($filename);
    
    if($file == false) {
        echo ("ERREUR: Ouverture impossible !");
        exit();
    }  

    $new = random_num(20);

    //Check if the id already exists in this table 
    $find = findWith($filename, $filesize, $new, 0);

    if($find[0] == true){
        fclose($file);
        return $find[1];
    }
}

function update($filename, $id, $arg, $new){
    
}

function delete($filename, $id){
    
}

function readAll($filename){
    
}

function findWith($filename, $filesize, $arg, $index){
    $isFound = false;
    $data = [];

    $file = fopen($filename,"r");
    $filesize = filesize($filename);

    $filetext = fread($file, $filesize);
    $lines = explode("\n",$filetext);
    
    for($i=0; $i<count($lines); $i++){
        $fields=explode(";", $lines[$i]);
    
        if(($arg==$fields[$index])){
            $isFound = true;
            $data = $fields;
            fclose($file);
            return [$isFound, $data];
        }
    }
    fclose($file);
    return [$isFound, $data];
}
?>